const Post = require('../models/post');
const User = require('../models/user');

module.exports.home = function(req,res){
    //printing cookie in console after every refresh of Home
    //console.log(req.cookies);

    //changing cookie(value)
   // res.cookie('user_id',24);
    

   //for showiwng posts on the home page
    /* Post.find({}, function(err,posts){
         return res.render('home',{
        title:"Codial | Home",
        posts : posts
    });
   });*/

   //(populate the user of each post)showing posts on the home page with userr name
   Post.find({})
   .populate('user')
   //showing comments with the name 
   .populate({
        path: 'comments',
        populate: {
            path: 'user'
        }
   })
   
   .exec(function(err,posts){
    
    //finding all the users
        User.find({}, function(err,users){
            return res.render('home',{
                title:"Codial | Home",
                posts : posts,
                all_users: users
                //going to home.ejs after this for creating sections
        });
   
    });
   });

   /*try{
    // CHANGE :: populate the likes of each post and comment
    let posts = await Post.find({})
    .sort('-createdAt')
    .populate('user')
    
        console.log('posts',posts);


    //let users = await User.find({});

    return res.render('home', {
        title: "Codeial | Home",
        posts:  posts,
    });

}catch(err){
    console.log('Error', err);
    return;
}*/



   
   
   
   
   
    //return res.end('<h1>Express is up for codeial!</h1>');
}
//this should be accessed in routes

/*module.exports.profile = function(req,res){
    return res.end('<h1>this is profile page!!</h1>');
}*/