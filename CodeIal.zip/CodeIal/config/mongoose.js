// getting-started.js
const mongoose = require('mongoose');



main().then(()=>{console.log("Connected to Database: MongoDB")}).catch(err => console.log(err));

async function main() {
  await mongoose.connect('mongodb://0.0.0.0:27017/CodeIal_Development');
  
}

const db = mongoose.Connection;

module.exports = db;


































/*const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/CodeIal_development');

const db = mongoose.connection;

db.on("error",console.error.bind(console,"Error connecting to MogoDB"));

db.once('open',function(){
    console.log('connected to database::MongoDB');
});


module.exports = db;*/