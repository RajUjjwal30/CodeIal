//post , comment
const mongoose = require('mongoose');

const postSchema = new mongoose.Schema({
    content: {
        type: String,
        required: true
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'

    },
    //include the ids of all comments in this post schema itself
    comments: [
        {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Comment'
        }
    ]

    
},{
    timestamps: true
});

const Post = mongoose.model('Post',postSchema);
module.exports = Post;

//next-step --> goto views and create a form from where this collection will have a document in it.(i.e. an entry is vreated in the database)