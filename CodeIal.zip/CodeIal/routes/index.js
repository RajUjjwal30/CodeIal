const express = require('express');

//creating/requiring router
const router = express.Router();

//accessing action of controller step 2
const homeController = require('../controllers/home_controller');
//accessing controller 1st step
router.get('/',homeController.home);

router.use('/user',require('./user'));
router.use('/posts',require('./posts'));
router.use('/comments',require('./comments'));

//router.get('/profile',homeController.profile);

//to know router is working
console.log('router loaded');

//to be available to use in index.js(main)
module.exports = router;